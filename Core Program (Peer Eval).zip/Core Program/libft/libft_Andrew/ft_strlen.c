/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dganapat <dganapat@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/23 12:48:13 by andmarti          #+#    #+#             */
/*   Updated: 2025/10/28 18:29:26 by dganapat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdio.h>
size_t	ft_strlen(const char *s)
{
	const char	*i;

	i = s;
	while (*i)
		i++;
	return ((size_t)(i - s));
}

int main(void)
{
    char    *str = "hello";
    printf("num: %zu", ft_strlen(str));
}
// hello
// s -> h [0]
// i -> h [0]
// i -> '\0' [5]