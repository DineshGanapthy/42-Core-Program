/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dganapat <dganapat@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/08 12:54:02 by andmarti          #+#    #+#             */
/*   Updated: 2025/10/28 18:17:18 by dganapat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	size_t  len;
	const char	*start;
	char       *mapped;

	if (!s || !f)
		return (NULL);
	start = s;
	len = ft_strlen(s);
	mapped = ft_calloc(len + 1, sizeof(char));
	if (!mapped)
		return (NULL);
	while (*s)
	{
		*mapped++ = f(s - start, *s);
		s++;
	}
	return (mapped - len);
}
