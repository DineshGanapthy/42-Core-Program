/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dganapat <dganapat@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/03 13:53:51 by chilim            #+#    #+#             */
/*   Updated: 2025/11/13 12:28:19 by dganapat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	count_substr(char const *s, char c)
{
	size_t	i;
	size_t	count;
	size_t	boolean;

	i = 0;
	count = 0;
	boolean = 0;
	if (!s)
		return (0);
	while (s[i])
	{
		if (s[i] != c && !boolean)
		{
			count++;
			boolean = 1;
		}
		else if (s[i] == c && boolean)
			boolean = 0;
		i++;
	}
	return (count);
}

static void	free_split(char **arr)
{
	size_t	i;

	i = 0;
	if (!arr)
		return ;
	while (arr[i])
	{
		free(arr[i]);
		i++;
	}
	free(arr);
}

static int	fill_substr(char **arr, char const *s, char c)
{
	size_t	start;
	size_t	end;
	size_t	i;

	i = 0;
	start = 0;
	while (s[start])
	{
		while (s[start] == c)
			start++;
		end = start;
		while (s[end] && s[end] != c)
			end++;
		if (end > start)
		{
			arr[i] = ft_substr(s, (unsigned int)start, end - start);
			if (!arr[i])
				return (0);
			i++;
		}
		start = end;
	}
	arr[i] = NULL;
	return (1);
}

char	**ft_split(char const *s, char c)
{
	char	**arr;
	size_t	substrc;

	if (!s)
		return (NULL);
	substrc = count_substr(s, c);
	arr = ft_calloc((substrc + 1), sizeof(char *));
	if (!arr)
		return (NULL);
	if (!fill_substr(arr, s, c))
	{
		free_split(arr);
		return (NULL);
	}
	return (arr);
}
#include <stdio.h> 
int		main()
{
	char s1[] = "Hello World";
	char c = ' ';
	int i;

	char **new = ft_split(s1,c);

	i = 0;
	while (new[i])
	{
		printf("%s\n" , new[i]);
		i++;
	}

	return (0);
}
