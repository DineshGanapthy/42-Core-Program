/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chilim <chilim@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/22 15:57:20 by chilim            #+#    #+#             */
/*   Updated: 2025/10/30 21:21:07 by chilim           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	i;
	size_t	dlen;
	size_t	slen;
	size_t	tofill;
	size_t	intendedlen;

	dlen = 0;
	slen = ft_strlen(src);
	while (dlen < size && dst[dlen] != '\0')
		dlen++;
	intendedlen = dlen + slen;
	if (size <= dlen)
		return (intendedlen);
	i = 0;
	tofill = size - dlen - 1;
	while (src[i] && tofill > 0)
	{
		dst[dlen++] = src[i++];
		tofill--;
	}
	dst[dlen] = '\0';
	return (intendedlen);
}
