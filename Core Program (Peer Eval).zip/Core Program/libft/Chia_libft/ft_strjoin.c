/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chilim <chilim@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/31 10:41:56 by chilim            #+#    #+#             */
/*   Updated: 2025/10/31 11:44:04 by chilim           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*str1;
	size_t	s1len;
	size_t	s2len;
	size_t	totallen;

	if (!s1 || !s2)
		return (NULL);
	s1len = ft_strlen(s1);
	s2len = ft_strlen(s2);
	totallen = s1len + s2len + 1;
	str1 = malloc(totallen * sizeof(char));
	if (!str1)
		return (NULL);
	ft_strlcpy(str1, s1, s1len + 1);
	ft_strlcat(str1, s2, s1len + s2len + 1);
	return (str1);
}
