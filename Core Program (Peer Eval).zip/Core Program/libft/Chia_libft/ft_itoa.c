/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dganapat <dganapat@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/01 17:06:17 by chilim            #+#    #+#             */
/*   Updated: 2025/11/13 12:37:00 by dganapat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	digit_len(int n)
{
	long	num;
	size_t	count;

	num = (long)n;
	count = 0;
	if (num < 0)
	{
		num = -num;
		count++;
	}
	if (num == 0)
		return (count + 1);
	while (num > 0)
	{
		count++;
		num = num / 10;
	}
	return (count);
}

int

char	*ft_itoa(int n)
{
	size_t		len;
	long		nbr;
	char		*str;

	nbr = (long)n;
	len = digit_len(n);
	str = malloc((len + 1) * sizeof(char));
	if (!str)
		return (NULL);
	return (fill_arr(str, nbr, len));
}
