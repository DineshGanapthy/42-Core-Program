/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_p.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgoh <vgoh@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/07 16:01:11 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/10 17:40:49 by vgoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_p(void *ptr)
{
	unsigned long	address;
	int				len;

	if (!ptr)
	{
		ft_putstr_fd("(nil)", 1);
		return (5);
	}
	address = (unsigned long)ptr;
	len = 0;
	ft_putstr_fd("0x", 1);
	len += 2;
	len += ft_putnbr_base(address, 16, "0123456789abcdef");
	return (len);
}
