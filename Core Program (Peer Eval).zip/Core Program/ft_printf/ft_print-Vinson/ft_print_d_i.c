/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_d_i.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgoh <vgoh@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/10 11:59:36 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/10 17:15:01 by vgoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_d_i(int n)
{
	long	nbr;
	int		len;

	nbr = (long)n;
	len = 0;
	if (nbr < 0)
	{
		ft_putchar_fd('-', 1);
		len++;
		nbr = -nbr;
	}
	len += ft_putnbr_base((unsigned int)nbr, 10, "0123456789");
	return (len);
}
