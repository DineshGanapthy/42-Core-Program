/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgoh <vgoh@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/23 11:43:23 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/10 16:58:06 by vgoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

size_t	ft_strlen(const char *s)
{
	size_t	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}

/*int	main(void)
{
	printf("%zu\n", ft_strlen("hello world"));
	printf("%zu\n", ft_strlen(" "));
	printf("%zu\n", ft_strlen("203 gr gr gr"));
	printf("%zu\n", ft_strlen("\0"));
}*/
