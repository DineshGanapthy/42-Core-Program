/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgoh <vgoh@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/07 16:14:30 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/10 16:22:04 by vgoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putnbr_base(unsigned long n, int base, char *digits)
{
	int	len;

	len = 0;
	if (n >= (unsigned long)base)
		len += ft_putnbr_base(n / base, base, digits);
	ft_putchar_fd(digits[n % base], 1);
	len++;
	return (len);
}
