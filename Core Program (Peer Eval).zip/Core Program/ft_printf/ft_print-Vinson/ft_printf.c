/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dganapat <dganapat@student.42kl.edu.my>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/06 16:37:49 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/11 17:59:57 by dganapat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	format_spec(char format, va_list args)
{
	if (format == 'c')
		return (ft_print_c(va_arg(args, int)));
	if (format == 's')
		return (ft_print_s(va_arg(args, char *)));
	if (format == 'p')
		return (ft_print_p(va_arg(args, void *)));
	if (format == 'd' || format == 'i')
		return (ft_print_d_i(va_arg(args, int)));
	if (format == 'u')
		return (ft_print_u(va_arg(args, unsigned int)));
	if (format == 'x')
		return (ft_print_lowx(va_arg(args, unsigned int)));
	if (format == 'X')
		return (ft_print_upx(va_arg(args, unsigned int)));
	if (format == '%')
	{
		ft_putchar_fd('%', 1);
		return (1);
	}
	return (0);
}

int	ft_printf(const char *format, ...)
{
	va_list	args;
	int		i;
	int		printlen;

	va_start(args, format);
	i = 0;
	printlen = 0;
	while (format[i])
	{
		if (format[i] == '%' && format[i + 1])
			printlen += format_spec(format[++i], args);
		else
		{
			ft_putchar_fd(format[i], 1);
			printlen++;
		}
		i++;
	}
	va_end(args);
	return (printlen);
}
#include <stdio.h>
int	main()
{
	int	x = 42;
	unsigned int	y = 305441741;
	ft_printf("%c\n %s\n %p\n %d\n %i\n %u\n %x\n %X\n", 
	'A', "hello", &x, 2147483647, -2147483648, 300, y, y);

    
    printf("%c\n %s\n %p\n %d\n %i\n %u\n %x\n %X\n", 
	'A', "hello", &x, 2147483647, -2147483647, 300, y, y);

}

