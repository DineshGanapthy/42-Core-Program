/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vgoh <vgoh@student.42kl.edu.my>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/06 15:47:36 by vgoh              #+#    #+#             */
/*   Updated: 2025/11/10 17:58:14 by vgoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <stdlib.h>
# include <unistd.h>

int		ft_printf(const char *format, ...);
int		ft_print_c(char c);
int		ft_print_s(char *s);
int		ft_print_p(void *ptr);
int		ft_print_d_i(int n);
int		ft_print_u(unsigned int n);
int		ft_print_lowx(unsigned int n);
int		ft_print_upx(unsigned int n);
int		ft_putnbr_base(unsigned long n, int base, char *digits);
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *s, int fd);
size_t	ft_strlen(const char *s);

#endif
